import{a as t}from"../chunks/entry.C9QkjlEA.js";export{t as start};
